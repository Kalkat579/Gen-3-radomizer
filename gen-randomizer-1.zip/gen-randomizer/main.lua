-- Randomizer mod for the Gen 1 / 2 / 3 recomp (mod API 2).
--
-- Hooks used (all exist in the engine for every generation):
--   encounter.species   wild grass/cave encounters
--   trainer.party       trainer teams
--   pokemon.before_give starters, gifts, fossils, scripted mons
--
-- Randomization is deterministic: every pick is a hash of
-- (seed, context, original species), so the same seed always gives the
-- same result, and the same original species in the same area always maps
-- to the same replacement ("Per area" mode).

local mod = ...
local gen = mod.generation

mod.options:define({
  { key = "seed", type = "number", label = "Seed", default = 1,
    min = 0, max = 999999 },
  { key = "wild", type = "choice", label = "Wild Pokemon", default = "area",
    choices = { { "Off", "off" }, { "Per area", "area" },
                { "Chaos", "chaos" } } },
  { key = "trainers", type = "choice", label = "Trainers", default = "random",
    choices = { { "Off", "off" }, { "Random", "random" } } },
  { key = "gifts", type = "toggle", label = "Starters & gifts",
    default = true },
  { key = "similar", type = "toggle", label = "Similar strength",
    default = true },
  { key = "legendaries", type = "toggle", label = "Allow legendaries",
    default = false },
  { key = "abilities", type = "choice", label = "Abilities (Gen 3)",
    default = "off",
    choices = { { "Off", "off" }, { "Random", "random" } } },
  { key = "abilityBan", type = "toggle", label = "Ban bad abilities",
    default = true },
})

local function opt(key) return mod.options:get(key) end

-- ---------------------------------------------------------------------
-- species pool

local LEGENDARY = {
  ARTICUNO = true, ZAPDOS = true, MOLTRES = true, MEWTWO = true, MEW = true,
  RAIKOU = true, ENTEI = true, SUICUNE = true, LUGIA = true, HO_OH = true,
  CELEBI = true, REGIROCK = true, REGICE = true, REGISTEEL = true,
  LATIAS = true, LATIOS = true, KYOGRE = true, GROUDON = true,
  RAYQUAZA = true, JIRACHI = true, DEOXYS = true,
}

local allSpecies   -- sorted array of species names
local bst = {}      -- name -> base stat total (when the game exposes it)
local warned = false

local function buildAll()
  local list = {}
  local maxDex = (gen == 2) and 251 or 151
  local ok, err = pcall(function()
    for id, rec in mod.content.pokemon:each() do
      if type(id) == "string" and type(rec) == "table"
          and (gen == 3 or (type(rec.dex) == "number" and rec.dex >= 1
                            and rec.dex <= maxDex)) then
        list[#list + 1] = id
        if type(rec.baseStats) == "table" then
          local sum = 0
          for _, v in pairs(rec.baseStats) do
            if type(v) == "number" then sum = sum + v end
          end
          bst[id] = sum
        end
      end
    end
  end)
  if not ok then
    mod.log:warn("could not read the species registry: %s", tostring(err))
  end
  table.sort(list) -- pairs() order is not stable; the seed must be
  return list
end

local function pool()
  if not allSpecies then allSpecies = buildAll() end
  if #allSpecies == 0 and not warned then
    warned = true
    mod.log:warn("no species found for generation %s; randomizer idle",
      tostring(gen))
  end
  local out = {}
  local allowLegends = opt("legendaries") == true
  for _, name in ipairs(allSpecies) do
    if allowLegends or not LEGENDARY[name] then out[#out + 1] = name end
  end
  return out
end

-- ---------------------------------------------------------------------
-- deterministic hash (pure double arithmetic, identical on every device)

local function hash(seed, ...)
  local parts = { tostring(seed) }
  for i = 1, select("#", ...) do parts[#parts + 1] = tostring((select(i, ...))) end
  local s = table.concat(parts, "|")
  local h = 5381
  for i = 1, #s do h = (h * 33 + s:byte(i)) % 2147483647 end
  local x = h % 2147483646 + 1
  for _ = 1, 4 do x = (x * 48271) % 2147483647 end
  return x
end

local function narrow(list, orig)
  if opt("similar") ~= true or not bst[orig] then return list end
  local target, window = bst[orig], 60
  local out
  repeat
    out = {}
    for _, name in ipairs(list) do
      local v = bst[name]
      if v and math.abs(v - target) <= window then out[#out + 1] = name end
    end
    window = window + 40
  until #out >= 8 or window > 500
  if #out == 0 then return list end
  return out
end

-- the replacement for `orig`; `key` scopes the pick (area, trainer slot...)
local function pickFor(orig, key)
  local list = pool()
  if #list == 0 then return nil end
  local candidates = narrow(list, orig)
  local seed = tonumber(opt("seed")) or 0
  return candidates[hash(seed, key, orig) % #candidates + 1]
end

local function randomPick(orig)
  local list = pool()
  if #list == 0 then return nil end
  local candidates = narrow(list, orig)
  return candidates[math.random(1, #candidates)]
end

local function shallowCopy(t)
  local c = {}
  for k, v in pairs(t) do c[k] = v end
  return c
end

-- ---------------------------------------------------------------------
-- wild encounters

mod.hooks:wrap("encounter.species", function(nextFn, enc, ctx)
  local out = nextFn(enc, ctx)
  local mode = opt("wild")
  if mode == "off" or type(out) ~= "table" then return out end
  local orig = out.species
  if type(orig) ~= "string" then return out end
  local new
  if mode == "chaos" then
    new = randomPick(orig)
  else
    new = pickFor(orig, "wild|" .. tostring(ctx and ctx.mapId or "?"))
  end
  if not new then return out end
  local copy = shallowCopy(out)
  copy.species = new
  copy.speciesId = nil -- Gen 3 resolves the id from the name
  return copy
end)

-- ---------------------------------------------------------------------
-- trainer teams

mod.hooks:wrap("trainer.party", function(nextFn, class, index, party)
  local out = nextFn(class, index, party)
  if opt("trainers") ~= "random" or type(out) ~= "table" then return out end
  local result = {}
  for i, slot in ipairs(out) do
    if type(slot) == "table" and type(slot.species) == "string" then
      local copy = shallowCopy(slot)
      local new = pickFor(slot.species,
        "trainer|" .. tostring(class) .. "|" .. tostring(index) .. "|" .. i)
      if new then
        copy.species = new
        copy.moves = nil -- let the new species use its own level-up moves
      end
      result[i] = copy
    else
      result[i] = slot
    end
  end
  return result
end)

-- ---------------------------------------------------------------------
-- starters, gifts, fossils

mod.events:on("pokemon.before_give", function(gift)
  if opt("gifts") ~= true then return end
  if type(gift.species) ~= "string" then return end
  local new = pickFor(gift.species, "gift")
  if new then gift.species = new end
end)

-- ---------------------------------------------------------------------
-- abilities (Gen 3 only: Gen 1 and 2 have none)
--
-- Abilities live on the species, so this patches each species once, at
-- load. Changing the option takes effect on the next launch. Every
-- individual keeps its slot: species with two abilities still give a
-- second one to half their Pokemon.

local ABILITY_MAX = 77
local NO_EFFECT = { [59] = true, [76] = true } -- Forecast (off Castform), Cacophony
local BAD = { [25] = true, [54] = true }       -- Wonder Guard, Truant

local function abilityPool()
  local out, ban = {}, opt("abilityBan") == true
  for id = 1, ABILITY_MAX do
    if not NO_EFFECT[id] and not (ban and BAD[id]) then out[#out + 1] = id end
  end
  return out
end

local function randomizeAbilities()
  if gen ~= 3 or opt("abilities") ~= "random" then return end
  if not allSpecies then allSpecies = buildAll() end
  local list = abilityPool()
  local seed = tonumber(opt("seed")) or 0
  local done, failed = 0, nil
  for _, name in ipairs(allSpecies) do
    local ok, err = pcall(function()
      local rec = mod.content.pokemon:get(name)
      local count = (type(rec) == "table" and type(rec.abilities) == "table")
        and #rec.abilities or 1
      local first = list[hash(seed, "ability", name, 1) % #list + 1]
      local abilities = { first }
      if count >= 2 then
        local h = hash(seed, "ability", name, 2)
        local second = list[h % #list + 1]
        if second == first then second = list[(h + 1) % #list + 1] end
        abilities[2] = second
      end
      mod.content.pokemon:patch(name, { abilities = abilities })
    end)
    if ok then done = done + 1 elseif not failed then failed = err end
  end
  if failed then
    mod.log:warn("some ability patches failed: %s", tostring(failed))
  end
  mod.log:info("randomized abilities for %d species", done)
end

randomizeAbilities()

mod.log:info("loaded (generation %s)", tostring(gen))
